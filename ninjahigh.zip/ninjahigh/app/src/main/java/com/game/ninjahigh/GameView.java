package com.game.ninjahigh;

import android.content.Context;
import android.graphics.*;
import android.media.SoundPool;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Iterator;

public class GameView extends SurfaceView implements Runnable {

    enum GameState { RUNNING, GAME_OVER }

    GameState gameState = GameState.RUNNING;

    Thread thread;
    SurfaceHolder holder;
    Paint paint;

    Player player;
    ArrayList<Enemy> enemies;
    ScoreManager score;

    float screenW, screenH;
    float worldOffsetY;

    float touchStartX;
    long enemyTimer;

    SoundPool soundPool;
    int restartSound;
    Vibrator vibrator;

    public GameView(Context context) {
        super(context);

        holder = getHolder();
        paint = new Paint();

        screenW = getResources().getDisplayMetrics().widthPixels;
        screenH = getResources().getDisplayMetrics().heightPixels;

        vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);

        soundPool = new SoundPool.Builder().setMaxStreams(2).build();
        restartSound = soundPool.load(context, R.raw.restart, 1);

        resetGame();

        thread = new Thread(this);
        thread.start();
    }

    void resetGame() {
        player = new Player(screenW, screenH);
        enemies = new ArrayList<>();
        score = new ScoreManager();
        worldOffsetY = 0;
        enemyTimer = System.currentTimeMillis();
        gameState = GameState.RUNNING;
    }

    @Override
    public void run() {
        while (true) {
            if (holder.getSurface().isValid()) {
                if (gameState == GameState.RUNNING) {
                    update();
                }
                draw();
            }
            try { Thread.sleep(16); } catch (Exception ignored) {}
        }
    }

    void update() {
        player.update(screenW);
        worldOffsetY = player.yWorld - player.yScreen;
        score.update(player.yWorld);

        if (System.currentTimeMillis() - enemyTimer > 1200) {
            enemies.add(new Enemy(screenW, player.yWorld - screenH));
            enemyTimer = System.currentTimeMillis();
        }

        Iterator<Enemy> it = enemies.iterator();
        while (it.hasNext()) {
            Enemy e = it.next();
            e.update();

            if (e.collide(player)) {
                gameState = GameState.GAME_OVER;
                vibrate();
            }

            if (e.yWorld - worldOffsetY > screenH + 100) {
                it.remove();
            }
        }
    }

    void draw() {
        Canvas canvas = holder.lockCanvas();
        canvas.drawColor(Color.rgb(120, 190, 255));

        paint.setColor(Color.DKGRAY);
        canvas.drawRect(0, 0, 30, screenH, paint);
        canvas.drawRect(screenW - 30, 0, screenW, screenH, paint);

        paint.setColor(Color.BLACK);
        canvas.drawRect(
                player.x - 20,
                player.yScreen - 20,
                player.x + 20,
                player.yScreen + 20,
                paint
        );

        paint.setColor(Color.RED);
        for (Enemy e : enemies) {
            float yScreen = e.yWorld - worldOffsetY;
            canvas.drawCircle(e.x, yScreen, 25, paint);
        }

        paint.setColor(Color.WHITE);
        paint.setTextSize(50);
        canvas.drawText("Score: " + score.getScore(), 40, 80, paint);

        if (gameState == GameState.GAME_OVER) {
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(80);
            canvas.drawText("GAME OVER", screenW / 2, screenH / 2, paint);
            paint.setTextSize(40);
            canvas.drawText("Tap to Restart",
                    screenW / 2,
                    screenH / 2 + 80,
                    paint);
            paint.setTextAlign(Paint.Align.LEFT);
        }

        holder.unlockCanvasAndPost(canvas);
    }

    void vibrate() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(
                    VibrationEffect.createOneShot(
                            300,
                            VibrationEffect.DEFAULT_AMPLITUDE
                    )
            );
        } else {
            vibrator.vibrate(300);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if (gameState == GameState.GAME_OVER &&
            event.getAction() == MotionEvent.ACTION_DOWN) {

            soundPool.play(restartSound, 1, 1, 1, 0, 1);
            resetGame();
            return true;
        }

        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            touchStartX = event.getX();
        }

        if (event.getAction() == MotionEvent.ACTION_UP &&
            gameState == GameState.RUNNING) {

            float diff = event.getX() - touchStartX;

            if (Math.abs(diff) > 80) {
                if (diff > 0) player.moveRight();
                else player.moveLeft();
            }
        }
        return true;
    }
}