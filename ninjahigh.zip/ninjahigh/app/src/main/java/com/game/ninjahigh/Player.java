package com.game.ninjahigh;

public class Player {

    public float x;
    public float yScreen;   // fixed position on screen
    public float yWorld;    // actual world movement

    public boolean onLeftWall = true;
    float speedY = -9;

    public Player(float screenW, float screenH) {
        yScreen = screenH * 0.65f;
        yWorld = 0;
        x = 50;
    }

    public void update(float screenW) {
        yWorld += speedY;
        x = onLeftWall ? 50 : screenW - 50;
    }

    public void moveLeft() {
        onLeftWall = true;
    }

    public void moveRight() {
        onLeftWall = false;
    }
}