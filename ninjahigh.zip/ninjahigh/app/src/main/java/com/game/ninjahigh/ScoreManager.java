package com.game.ninjahigh;

public class ScoreManager {

    int score = 0;

    void update(float worldY) {
        score = (int) Math.abs(worldY / 10);
    }

    int getScore() {
        return score;
    }

    void reset() {
        score = 0;
    }
}