package com.game.ninjahigh;

import java.util.Random;

public class Enemy {

    float x;
    float yWorld;
    float size = 50;
    float speed = 7;

    public Enemy(float screenW, float spawnWorldY) {
        Random r = new Random();
        x = r.nextBoolean() ? 50 : screenW - 50;
        yWorld = spawnWorldY;
    }

    void update() {
        yWorld += speed;
    }

    boolean collide(Player p) {
        return Math.abs(p.x - x) < 40 &&
               Math.abs(p.yWorld - yWorld) < 40;
    }
}